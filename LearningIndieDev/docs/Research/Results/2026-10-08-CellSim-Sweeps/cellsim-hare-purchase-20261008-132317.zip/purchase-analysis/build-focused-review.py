"""Summarize completed purchase evidence; preserve frozen inputs and raw reports."""
import csv
import hashlib
import json
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
data=json.loads((HERE/'results.json').read_text())
records=data['records']
lookup={(r['candidate'],r['path'],r['purchasePolicy']):r for r in records}
candidates=list(dict.fromkeys(r['candidate'] for r in records))
policies=list(dict.fromkeys(r['purchasePolicy'] for r in records))
paths=['trailblazer','warren','gardeners']
def mean(r,k): return float(r[k]['mean'])
def delta(r,k,suffix):
    p=r[k+suffix]
    return float(p['mean']) if p and p['mean'] else 0.
def percentage(r,k): return f'{mean(r,k)*100:.0f}%'
def pair(r,k,suffix): return f'{round(delta(r,k,suffix)*100):+d}'
def table(lines,headers,rows):
    lines.append('| '+' | '.join(headers)+' |')
    lines.append('| '+' | '.join(['---']*len(headers))+' |')
    lines.extend('| '+' | '.join(row)+' |' for row in rows)
    lines.append('')
summary=json.loads((ROOT/'sweep/batch/summary.json').read_text())
pipeline=json.loads((ROOT/'pipeline-state.json').read_text())
assert pipeline['state']==summary['state']=='Completed' and summary['runs']==12800
assert len(records)==128 and all(r[k]['n']=='100' and r[k]['invalid']==r[k]['missing']=='0'
    for r in records for k in ('hareSurvival','allSpeciesSurvival','meanAPS','meanAHS'))
with (HERE/'windows.csv').open(newline='') as stream: windows=list(csv.DictReader(stream))
assert len(windows)==len({(w['condition'],w['seed'],w['phase']) for w in windows})==64000
qualifications={}
for candidate in candidates:
    own=[]; skip=[]
    for policy in policies:
        arm=[lookup[candidate,path,policy] for path in paths]
        if policy!='none' and all(delta(r,k,'VsNoPurchase')>1e-9 for r in arm for k in ('hareSurvival','allSpeciesSurvival')): own.append(policy)
        if all(delta(r,k,'VsSkipAllSamePurchase')>1e-9 for r in arm for k in ('hareSurvival','allSpeciesSurvival')): skip.append(policy)
    qualifications[candidate]=dict(allThreePathsImproveBothVsOwnNoPurchases=own,allThreePathsImproveBothVsSamePurchaseSkipAll=skip)
lines=['# Completed Hare purchase panel: focused review','',
    'Analysis by Codex / GPT-6 on 2026-10-08. Human owner: Bevin. Scope was approved; production tuning and follow-up selection remain human decisions.','',
    f'12,800 assigned runs completed with 16 workers in {summary["elapsedSeconds"]/60:.2f} simulation minutes; automatic analysis completed at 14:15 EDT. All 128 arms have 100 fresh matched seeds (50000–50099). APS/AHS have Valid n=100 in every arm. Frozen input, aggregate and analysis hashes were checked on completion review.','',
    'Observed: restoring toward the starting Hare count improved both survival endpoints across all three paths in D4/S19, D4/S14 and D5/S25. C2/S14 Gardeners declined. Late-five was the only tested policy with positive observed purchase effects on both survival endpoints in all twelve candidate/path arms. Early-five reduced all-species survival in 14 of 16 arms, was neutral in one, and improved one by one percentage point.','',
    'Interpretation: timing and current population appear more useful than unconditional early reinforcement. This screen does not establish the ecological cause or prove gameplay enjoyment. Survival gains often accompany lower APS/AHS; direct purchases are ADD rather than births and are excluded from biological growth accounting.','',
    '## Restore toward starting population','',
    'Buy up to five at each reached window, only while below the original Hare count. Arrow columns compare no purchases with restoration on the same path. ΔSkip is all-species survival versus Skip all with the same restoration policy. All survival measures are at tick 600; deltas are percentage points. APS/AHS are per-run means over actual observed durations, including early-ended runs, with 100 valid samples.','']
rows=[]
for c in candidates:
    for path in paths:
        r=lookup[c,path,'restore-toward-start']; b=lookup[c,path,'none']
        rows.append([c.replace('-','/'),path,percentage(b,'hareSurvival')+' → '+percentage(r,'hareSurvival'),
            percentage(b,'allSpeciesSurvival')+' → '+percentage(r,'allSpeciesSurvival'),
            pair(r,'allSpeciesSurvival','VsSkipAllSamePurchase'),f'{mean(r,"meanAPS"):.3f}',f'{mean(r,"meanAHS"):.3f}'])
table(lines,['Candidate','Path','Hare alive: no buy → restore','All alive: no buy → restore','ΔSkip all alive','Mean APS','Mean AHS'],rows)
lines+=['## Largest individual all-species survival result','',
    'D5/S25 Gardeners with each-five had the highest observed all-species survival in this panel, 59%. Its matched gain versus no purchases was +20 pp (35 wins / 15 losses; unadjusted approximate 95% CI +6.6 to +33.4 pp). Relative to Skip all with the same purchase policy it was +26 pp. This maximum was selected from 128 arms and needs fresh-seed confirmation.','']
rows=[]
for policy in ['none','late-five','restore-toward-start','each-five']:
    r=lookup['D5-S25','gardeners',policy]
    rows.append([policy,percentage(r,'hareSurvival'),percentage(r,'allSpeciesSurvival'),
        f'{mean(r,"meanAPS"):.3f}',f'{mean(r,"meanAHS"):.3f}',f'{mean(r,"added"):.2f}',f'{mean(r,"spent"):.1f}'])
table(lines,['D5/S25 Gardeners policy','Hare alive','All alive','Mean APS','Mean AHS','Mean ADD','Mean Field Data spent'],rows)
lines+=['## Purchase-effect matrix','',
    'Each cell is the all-species survival change versus the same path with no purchases, ordered Trailblazer / Warren / Gardeners, in percentage points. This comparison isolates buying; it is different from beating Skip all when both arms use the same purchase policy.','']
table(lines,['Policy']+[c.replace('-','/') for c in candidates],[[policy]+[
    ' / '.join(pair(lookup[c,path,policy],'allSpeciesSurvival','VsNoPurchase') for path in paths)
    for c in candidates] for policy in policies])
lines+=['## Both-endpoint all-path qualification','',
    'Positive here means positive observed matched point estimates for Hare survival and all-species survival on all three paths. It does not imply all confidence intervals exclude zero.','']
table(lines,['Candidate','Purchases improve all three paths vs own no-buy','All three paths beat Skip all with same buys'],[
    [c.replace('-','/'),', '.join(q['allThreePathsImproveBothVsOwnNoPurchases']),', '.join(q['allThreePathsImproveBothVsSamePurchaseSkipAll'])]
    for c,q in qualifications.items()])
counts=dict(Counter(w['stopReason'] for w in windows))
lines+=['## Diagnostics and next decisions','',
    f'All 64,000 assigned window rows exist: 57,532 reached; 6,468 not reached. Stop reasons: {counts}. No placement/capacity stops were observed in this panel. Means of additions and spending retain all assigned seeds, including zero purchases. Currency totals describe the five eligible windows; final-run rewards remain separately recorded.','',
    'Suggested follow-ups for Bevin: prioritize D5/S25 restoration for shared path support, contrast D5/S25 Gardeners each-five with restoration and late-five for spend/survival/APS tradeoffs, and retain D4/S14 Gardeners restoration as another strong arm. Keep C2/S14 as a context-dependent comparison. No follow-up run is launched or production change approved by this analysis.','',
    'Limits: 100 seeds per arm; many exploratory comparisons; selecting maxima adds optimism. Mean confidence intervals and McNemar values are unadjusted. Paired rows retain different-window counts; compare rate changes with actual observation durations. A lower AHS does not itself establish Fox extinction or a worse player experience. Tick-700 ecology viability and enjoyment require separate evidence.','',
    'Evidence: report.md (all 128 arms), results.json (means/statuses/paired uncertainty), windows.csv (assigned windows and following-phase recovery), ../analysis/metrics.csv, ../analysis/paired-deltas.csv and ../analysis/metrics.sqlite.','',
    'Batch identity: `'+data['provenance']['batchIdentity']+'`. Raw SHA256: `'+data['provenance']['rawHash']+'`.']
(HERE/'focused-review.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
(HERE/'focused-review.json').write_text(json.dumps(dict(recordedUtc=datetime.now(timezone.utc).isoformat(),
    provenance=data['provenance'],sourceResultsHash=hashlib.sha256((HERE/'results.json').read_bytes()).hexdigest(),
    coverage=dict(runs=12800,arms=128,samplesPerArm=100,APSValidPerArm=100,AHSValidPerArm=100,windows=64000),
    windowStops=counts,qualifications=qualifications),indent=2)+'\n')
print('Wrote focused-review.md/json; verified assigned window coverage and all-arm metric sample/status coverage.')
