"""Post-hoc matched-seed screen. Reads frozen observations; launches no runs."""
import hashlib
import json
import math
import sqlite3
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = Path(__file__).resolve().parent
PATHS = ("trailblazer", "warren", "gardeners")
POPULATIONS = ("100-10-5", "175-15-8", "250-20-10", "325-30-15", "400-40-20")
MAPS = ("30x18", "36x20", "42x24", "48x28", "54x32")
ENERGIES = ("40", "60", "80", "120", "160")
VISIONS = ("5", "6", "7", "8", "9")


def exact_two_sided(wins, losses):
    n = wins + losses
    return min(1.0, 2 * sum(math.comb(n, k) for k in range(min(wins, losses) + 1)) / 2**n) if n else 1.0


def compare(values, reference):
    assert set(values) == set(reference) == set(range(40000, 40100))
    differences = [values[s] - reference[s] for s in sorted(values)]
    n = len(differences)
    mean = sum(differences) / n
    sd = math.sqrt(sum((d - mean)**2 for d in differences) / (n - 1))
    wins = differences.count(1)
    losses = differences.count(-1)
    return dict(successes=sum(values.values()), baselineSuccesses=sum(reference.values()),
                n=n, deltaPP=100 * sum(differences) / n, wins=wins, losses=losses, ties=n-wins-losses,
                pairedNormalCI95PP=[100*(mean-1.96*sd/math.sqrt(n)), 100*(mean+1.96*sd/math.sqrt(n))],
                exactMcNemarTwoSidedP=exact_two_sided(wins, losses))


assert exact_two_sided(0, 0) == 1
assert exact_two_sided(6, 0) == 0.03125
assert exact_two_sided(4, 2) == 0.6875
assert exact_two_sided(6, 0) == exact_two_sided(0, 6)
fixture = compare({s:int(s < 40010) for s in range(40000,40100)}, {s:0 for s in range(40000,40100)})
assert (fixture["successes"],fixture["baselineSuccesses"],fixture["deltaPP"],fixture["wins"],fixture["losses"],fixture["ties"]) == (10,0,10,10,0,90)
assert fixture["pairedNormalCI95PP"][0] > 0

db = sqlite3.connect((ROOT / "analysis/metrics.sqlite").as_uri() + "?mode=ro", uri=True)
provenance = json.loads(db.execute("SELECT metadata FROM provenance").fetchone()[0])
analysis = json.loads((ROOT / "analysis/analysis.json").read_text(encoding="utf-8"))
assert provenance["rawHash"] == analysis["rawHash"]
assert provenance["batchIdentity"] == analysis["batchIdentity"]
assert provenance["sweepHash"] == hashlib.sha256((ROOT / "sweep/sweep.json").read_bytes()).hexdigest()
assert dict(db.execute("SELECT column_name,metric FROM metrics"))["m1"] == "outcome.allSpeciesAliveAtHorizon"
assert dict(db.execute("SELECT column_name,metric FROM metrics"))["m0"] == "outcome.playerAliveAtHorizon"
cases = {condition: json.loads(metadata) for condition, metadata in db.execute("SELECT * FROM cases")}
assert len(cases) == 2500
groups = defaultdict(dict)
for case in cases.values():
    assert case["path"] not in groups[case["context"]]
    groups[case["context"]][case["path"]] = case
assert len(groups) == 625
rows = defaultdict(lambda: {"allSpecies": {}, "hare": {}})
count = 0
for condition, seed, all_alive, all_status, hare_alive, hare_status in db.execute(
        "SELECT condition,seed,m1,s1,m0,s0 FROM observations WHERE phase=0"):
    assert condition in cases and all_status == hare_status == 0
    assert all_alive in (0, 1) and hare_alive in (0, 1)
    assert seed not in rows[condition]["allSpecies"]
    rows[condition]["allSpecies"][seed] = int(all_alive)
    rows[condition]["hare"][seed] = int(hare_alive)
    count += 1
assert count == 250000
assert all(set(r["allSpecies"]) == set(range(40000, 40100)) for r in rows.values())
records = []
for context, paths in groups.items():
    assert set(paths) == {"skip-all", *PATHS}
    base = paths["skip-all"]
    axes = base["axes"]
    assert all(c["axes"] == axes and c["reference"] == base["id"] for p, c in paths.items() if p != "skip-all")
    outer = chr(65 + POPULATIONS.index(axes["populations"])) + str(MAPS.index(axes["grid"]) + 1)
    stat = "S" + str(ENERGIES.index(axes["fox-energy"]) * 5 + VISIONS.index(axes["hare-vision"]) + 1).zfill(2)
    record = dict(context=context, matrixCell=outer+"/"+stat, axes=axes, conditions={p:c["id"] for p,c in paths.items()})
    for metric in ("allSpecies", "hare"):
        comparisons = {p: compare(rows[paths[p]["id"]][metric], rows[base["id"]][metric]) for p in PATHS}
        record[metric] = dict(comparisons=comparisons,
            allThreePositive=all(c["deltaPP"] > 0 for c in comparisons.values()),
            minDeltaPP=min(c["deltaPP"] for c in comparisons.values()),
            minLowerCI95PP=min(c["pairedNormalCI95PP"][0] for c in comparisons.values()),
            allThreeExactUnadjusted05=all(c["deltaPP"] > 0 and c["exactMcNemarTwoSidedP"] < .05 for c in comparisons.values()),
            allThreeExactBonferroni05=all(c["deltaPP"] > 0 and c["exactMcNemarTwoSidedP"] < .05/(625*3) for c in comparisons.values()))
    records.append(record)
db.close()
known = next(r for r in records if r["matrixCell"] == "D5/S15")
assert known["allSpecies"]["comparisons"]["gardeners"]["successes"] == 68
assert known["allSpecies"]["comparisons"]["gardeners"]["baselineSuccesses"] == 16
assert not known["allSpecies"]["allThreePositive"]
summary = {}
for metric in ("allSpecies", "hare"):
    ranked = sorted((r for r in records if r[metric]["allThreePositive"]),
        key=lambda r: (-r[metric]["minDeltaPP"], -r[metric]["minLowerCI95PP"], r["matrixCell"]))
    summary[metric] = dict(allThreePositive=len(ranked),
        allThreeLowerCIAboveZero=sum(r[metric]["minLowerCI95PP"] > 0 for r in ranked),
        allThreeExactUnadjusted05=sum(r[metric]["allThreeExactUnadjusted05"] for r in ranked),
        allThreeExactBonferroni05=sum(r[metric]["allThreeExactBonferroni05"] for r in ranked),
        topCells=[r["matrixCell"] for r in ranked[:20]])
both_positive = sum(r["allSpecies"]["allThreePositive"] and r["hare"]["allThreePositive"] for r in records)
payload = dict(schemaVersion=1, generatedUTC=datetime.now(timezone.utc).isoformat(),
    question="Which frozen starting contexts improve all three Hare paths versus same-context Skip all?",
    source=str(ROOT / "analysis/metrics.sqlite"), provenance=provenance, runs=count, contexts=len(records),
    primaryMetric="allSpecies", secondaryMetric="hare", phase=0, horizonTicks=600, matchedSeeds=100,
    ranking="Descending smallest path delta, then smallest paired normal confidence lower bound; stable cell ID tie-break",
    inference="Post-hoc exploratory screen. Primary allSpecies and secondary Hare survival reported separately. Normal paired CIs and exact two-sided McNemar tests unadjusted; conservative Bonferroni flags within each metric family of 625x3 comparisons also reported. No production or gameplay approval. Fresh seeds required for confirmation.",
    summary=summary, bothMetricsAllThreePositive=both_positive, records=sorted(records,key=lambda r:r["matrixCell"]))
(OUT / "results.json").write_text(json.dumps(payload, indent=2, sort_keys=True)+"\n",encoding="utf-8")
lines = ["# All three Hare paths versus Skip all", "", "Post-hoc analysis of the completed quarter-million sweep. No simulations launched.",
    "", f"Generated UTC: {payload['generatedUTC']}", "", "Each row fixes populations, map, Fox energy and Hare vision; all four paths use the same 100 seeds (40000-40099). Outcomes measured at tick 600. Positive benefit means a strictly greater success count, not merely a tie.",
    "", "Primary: all three species alive. Secondary: Hare species alive. Ranked by the smallest gain across Trailblazer, Warren and Gardeners; large gains in one path cannot compensate for another path's loss.", "", f"{both_positive}/625 contexts improve all three paths on BOTH endpoints.", ""]
for metric, label in [("allSpecies", "All-species survival"), ("hare", "Hare survival")]:
    s = summary[metric]
    lines += ["## " + label, "", f"{s['allThreePositive']}/625 contexts show positive observed benefit for all three paths. {s['allThreeLowerCIAboveZero']} have all three paired normal 95% lower bounds above zero; {s['allThreeExactUnadjusted05']} pass all three unadjusted exact two-sided tests at p<0.05; {s['allThreeExactBonferroni05']} pass all three conservative Bonferroni tests (0.05/1875 within this metric family).", "",
        "| Cell | P/H/F | Map | Fox energy | Hare vision | Skip all | Trailblazer | Warren | Gardeners | Smallest gain (pp) |", "|---|---|---|---|---|---|---|---|---|---|"]
    for cell in s["topCells"]:
        r = next(r for r in records if r["matrixCell"] == cell)
        a, comps = r["axes"], r[metric]["comparisons"]
        base = comps[PATHS[0]]["baselineSuccesses"]
        values = [f"{comps[p]['successes']}% (+{comps[p]['deltaPP']:.0f})" for p in PATHS]
        lines.append(f"| {cell} | {a['populations']} | {a['grid']} | {a['fox-energy']} | {a['hare-vision']} | {base}% | {' | '.join(values)} | {r[metric]['minDeltaPP']:.0f} |")
    lines.append("")
lines += ["## Evidence and limits", "", "- SQLite provenance agrees with frozen sweep hash, analysis batch identity and raw hash; all 250,000 phase-zero observations valid, binary and covered exactly once; each arm contains all 100 expected unique seeds.",
    "- D5/S15 reproduces the known 68 Gardeners versus 16 Skip-all all-species result; it is not an all-path-positive context.",
    "- results.json includes all 625 contexts, per-path successes, matched wins/losses/ties, paired normal intervals, exact two-sided p values, condition IDs and source provenance.",
    "- At 100 seeds per arm, small positive gains may be sampling variation. Selection over the complete grid makes the shortlist optimistic. Even adjusted flags do not replace fresh-seed replication.",
    "- All-species survival and Hare survival are different goals. Longer horizons, mechanism diagnostics and gameplay quality are not established by these endpoints.",
    "- Shared seeds correlate cross-context results. Treat counts of qualifying contexts as descriptive, not independent replications.",
    "- Full original raw JSONL hash was verified during completion review; this follow-up checks stored provenance and SQLite coverage without rereading the 10.88 GB raw file.",
    "- Source: ../analysis/metrics.sqlite; ../analysis/analysis.json; ../sweep/sweep.json. Analyst: Codex, GPT-6; interpretation is generated evidence for human review.", ""]
(OUT / "report.md").write_text("\n".join(lines),encoding="utf-8")
print(json.dumps(summary,indent=2))
print("KNOWN_WINNER",json.dumps(known))
print("TOP_PRIMARY",json.dumps(sorted((r for r in records if r['allSpecies']['allThreePositive']),key=lambda r:(-r['allSpecies']['minDeltaPP'],-r['allSpecies']['minLowerCI95PP'],r['matrixCell']))[:3]))
