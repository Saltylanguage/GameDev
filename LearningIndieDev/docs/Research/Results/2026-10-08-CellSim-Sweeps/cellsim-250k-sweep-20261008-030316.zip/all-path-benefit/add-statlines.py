"""Add per-run mean Hare APS and Fox AHS without changing the survival ranking."""
import json
import math
import sqlite3
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent
PATHS = ("skip-all", "trailblazer", "warren", "gardeners")
LABELS = dict(zip(PATHS, ("Skip all", "Trailblazer", "Warren", "Gardeners")))
SELECTED = ("D4/S19", "D4/S14", "C2/S14", "D5/S25", "D5/S15")


def summary(observations, metric):
    valid = [r[metric][0] for r in observations.values() if r[metric][1] == 0]
    assert all(v is not None and math.isfinite(v) for v in valid)
    statuses = {label:sum(r[metric][1] == code for r in observations.values())
                for code,label in enumerate(("valid", "notApplicable", "invalid", "missing"))}
    assert sum(statuses.values()) == len(observations)
    return dict(mean=math.fsum(valid)/len(valid) if valid else None, n=len(valid), statuses=statuses)


def paired(observations, reference, metric):
    keys = sorted(set(observations) & set(reference))
    keys = [s for s in keys if observations[s][metric][1] == reference[s][metric][1] == 0]
    differences = [observations[s][metric][0]-reference[s][metric][0] for s in keys]
    different = sum(observations[s]["window"] != reference[s]["window"] for s in keys)
    return dict(meanDelta=math.fsum(differences)/len(keys) if keys else None, n=len(keys),
                differentWindows=different, sameWindows=len(keys)-different,
                unpairedOrUnavailable=100-len(keys))


# Meaningful self-check: unavailable values are excluded, never converted to zero.
fixture = {1:{"APS":(2.0,0)},2:{"APS":(None,1)},3:{"APS":(4.0,0)}}
assert summary(fixture,"APS") == dict(mean=3.0,n=2,statuses=dict(valid=2,notApplicable=1,invalid=0,missing=0))
fixture_a = {1:{"APS":(3.0,0),"window":(0,10)},2:{"APS":(None,1),"window":(0,20)}}
fixture_b = {1:{"APS":(1.0,0),"window":(0,20)},2:{"APS":(5.0,0),"window":(0,20)}}
assert paired(fixture_a,fixture_b,"APS") == dict(meanDelta=2.0,n=1,differentWindows=1,sameWindows=0,unpairedOrUnavailable=99)

original = json.loads((OUT / "results.json").read_text(encoding="utf-8"))
db = sqlite3.connect((ROOT / "analysis/metrics.sqlite").as_uri()+"?mode=ro", uri=True)
provenance = json.loads(db.execute("SELECT metadata FROM provenance").fetchone()[0])
assert provenance == original["provenance"]
definitions = {metric:(column,status) for column,metric,status in db.execute("SELECT * FROM metrics")}
aps,sa = definitions["herbivore.hare.APS"]
ahs,sh = definitions["predator.fox.AHS"]
assert all(name.isalnum() for name in (aps,sa,ahs,sh))
rows = defaultdict(dict)
for condition,seed,start,end,ap,ap_status,ah,ah_status in db.execute(
        f"SELECT condition,seed,start,end,{aps},{sa},{ahs},{sh} FROM observations WHERE phase=0"):
    assert seed not in rows[condition]
    assert 0 <= start <= end <= 600
    assert ap_status in range(4) and ah_status in range(4)
    assert (ap is not None) == (ap_status == 0)
    assert (ah is not None) == (ah_status == 0)
    rows[condition][seed] = dict(window=(start,end), APS=(ap,ap_status), AHS=(ah,ah_status))
assert len(rows) == 2500
assert sum(map(len,rows.values())) == 250000
assert all(set(r) == set(range(40000,40100)) for r in rows.values())
for record in original["records"]:
    baseline = rows[record["conditions"]["skip-all"]]
    statlines = {}
    for path in PATHS:
        condition = record["conditions"][path]
        observations = rows[condition]
        windows = [r["window"][1]-r["window"][0] for r in observations.values()]
        result = dict(observedTicks=dict(mean=math.fsum(windows)/100,min=min(windows),max=max(windows),
            reached600=sum(r["window"][1] == 600 for r in observations.values())))
        for metric in ("APS","AHS"):
            result[metric] = dict(summary(observations,metric), pairedVsSkipAll=paired(observations,baseline,metric))
            # Cross-check mean and valid denominator directly against independent SQL aggregation.
            col,status = (aps,sa) if metric == "APS" else (ahs,sh)
            n,mean = db.execute(f"SELECT count(*),avg({col}) FROM observations WHERE condition=? AND phase=0 AND {status}=0",(condition,)).fetchone()
            assert n == result[metric]["n"]
            assert mean is None and result[metric]["mean"] is None or math.isclose(mean,result[metric]["mean"],rel_tol=1e-12,abs_tol=1e-12)
            if n == 100:
                base_mean = summary(baseline,metric)["mean"]
                assert math.isclose(result[metric]["pairedVsSkipAll"]["meanDelta"],mean-base_mean,rel_tol=1e-12,abs_tol=1e-12)
        statlines[path] = result
    record["statlines"] = statlines
db.close()
original.update(schemaVersion=2,statlineGeneratedUTC=datetime.now(timezone.utc).isoformat(),
    originalSurvivalAnalysis=str(OUT/"results.json"),
    statlineAggregation="Arithmetic mean of Valid phase-zero per-run cumulative APS/AHS; equal weight per seed, including early extinction runs. Not a pooled-count ratio, per-tick rate or survivors-only mean. Unavailable values remain unavailable.",
    statlineWindows="Each cumulative statline covers tick zero through the actual run stop, up to 600 ticks. Paired deltas report the number of differing observation windows; they are descriptive endpoint comparisons, not isolated fixed-exposure effects.",
    metricDefinitions=dict(APS="herbivore.hare.APS",AHS="predator.fox.AHS"))
(OUT/"results-with-statlines.json").write_text(json.dumps(original,indent=2,sort_keys=True)+"\n",encoding="utf-8")
lines = ["# All-path benefit with average APS and AHS", "",
    f"Generated UTC: {original['statlineGeneratedUTC']}", "",
    "Source: completed cellsim-250k-sweep-20261008-030316; ../analysis/metrics.sqlite. Survival rankings and qualifying counts are unchanged: 129 all-species, 210 Hare, 96 both, out of 625 contexts.", "",
    "APS is the Hare composite; AHS is the Fox composite. Means give equal weight to each Valid per-run cumulative metric, retaining early extinction runs. They are not percentages or pooled event ratios. All 250,000 overall APS and AHS observations are Valid; all means below use 100/100 seeds. No unavailable value was treated as zero.", "",
    "Survival is assessed at tick 600. APS/AHS cover each run's observed tick-zero-to-stop window, which may end earlier. Scores and matched deltas are supporting descriptions of different realized trajectories, not fixed-exposure causal effects. Do not combine APS and AHS into one score or rank different starting populations on these composites alone.", ""]
assert all(r['statlines'][p][m]['n']==100 for r in original['records'] for p in PATHS for m in ('APS','AHS'))


def table(record):
    lines.extend(["| Path | All-species survival | Hare survival | Mean APS | Paired delta APS | Mean AHS | Paired delta AHS | Mean ticks | Different windows vs Skip all |",
                  "|---|---|---|---|---|---|---|---|---|"])
    for path in PATHS:
        c = record["allSpecies"]["comparisons"]["trailblazer"] if path=="skip-all" else record["allSpecies"]["comparisons"][path]
        h = record["hare"]["comparisons"]["trailblazer"] if path=="skip-all" else record["hare"]["comparisons"][path]
        survival = c["baselineSuccesses"] if path=="skip-all" else c["successes"]
        hare = h["baselineSuccesses"] if path=="skip-all" else h["successes"]
        s = record["statlines"][path]
        av,ah = s["APS"],s["AHS"]
        delta_aps = "reference" if path=="skip-all" else f"{av['pairedVsSkipAll']['meanDelta']:+.3f}"
        delta_ahs = "reference" if path=="skip-all" else f"{ah['pairedVsSkipAll']['meanDelta']:+.3f}"
        lines.append(f"| {LABELS[path]} | {survival}% | {hare}% | {av['mean']:.3f} | {delta_aps} | {ah['mean']:.3f} | {delta_ahs} | {s['observedTicks']['mean']:.1f} | {av['pairedVsSkipAll']['differentWindows']}/100 |")
    lines.append("")

by_cell = {r["matrixCell"]:r for r in original["records"]}
for cell in SELECTED:
    r=by_cell[cell]
    a=r["axes"]
    lines += [f"## {cell}","",f"Plants/Hares/Foxes {a['populations']}; grid {a['grid']}; Fox starting energy {a['fox-energy']}; Hare vision {a['hare-vision']}.",""]
    table(r)
lines += ["## Other shortlisted contexts", "", "Union of the top 20 ecosystem and top 20 Hare survival contexts, preserving the original rankings; cells above are not repeated.", ""]
additional = dict.fromkeys(original["summary"]["allSpecies"]["topCells"]+original["summary"]["hare"]["topCells"])
for cell in additional:
    if cell in SELECTED:
        continue
    r=by_cell[cell];a=r["axes"]
    lines += [f"### {cell}","",f"Plants/Hares/Foxes {a['populations']}; grid {a['grid']}; Fox energy {a['fox-energy']}; Hare vision {a['hare-vision']}.",""]
    table(r)
lines += ["## Verification and evidence limits", "",
    "- All 250,000 observations retain exactly the expected 100 unique seeds per arm. APS/AHS metric IDs resolved through the database metric registry, with status checks.",
    "- All 5,000 APS/AHS means and valid sample sizes independently cross-checked against SQL aggregates; paired mean differences checked against mean differences where all seeds valid.",
    "- Independent self-check proves unavailable values are excluded and differing windows counted correctly. Stored database provenance matches the prior survival analysis.",
    "- Source original survival analysis: results.json and report.md. Full enriched 625-context data: results-with-statlines.json. Script: add-statlines.py. Prior analyses and frozen run evidence remain intact.",
    "- No simulations or production tuning. Existing exploratory survival-screen limits and multiple-comparison caveats still apply. Phase-specific or common-window effects have not been isolated.",
    "- Generated interpretation by Codex, GPT-6. Human balance/gameplay acceptance remains pending.",""]
(OUT/"report-with-statlines.md").write_text("\n".join(lines),encoding="utf-8")
print("Validated 5,000 per-arm means; 625 contexts enriched; all APS/AHS n=100.")
for cell in SELECTED:
    print(cell,json.dumps(by_cell[cell]["statlines"],sort_keys=True))
